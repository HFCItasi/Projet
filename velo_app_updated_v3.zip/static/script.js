// Coordonnées des villes
const cityCoords = {
    'Lyon': [45.7640, 4.8357],
    'Amiens': [49.8941, 2.2957],
    'Nantes': [47.2184, -1.5536],
    'Toulouse': [43.6047, 1.4442]
};

// Initialiser la carte Leaflet centré sur la ville préférée
var initialCity = window.userPreferredCity || 'Lyon';
var initialCoords = cityCoords[initialCity] || cityCoords['Lyon'];
var map = L.map('map').setView(initialCoords, 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

var startMarker, endMarker;
var startCoords, endCoords;
var polylines = [];

// Zoomer sur la ville sélectionnée
document.getElementById('city-select').addEventListener('change', function() {
    const selectedCity = this.value;
    const coords = cityCoords[selectedCity];
    if (coords) {
        map.setView(coords, 13);
    }
});

// Ajouter un écouteur d'événements pour capturer les clics sur la carte
map.on('click', function(e) {
    if (!startMarker) {
        startMarker = L.marker(e.latlng).addTo(map).bindPopup('Point de départ').openPopup();
        startCoords = [e.latlng.lat, e.latlng.lng];
    } else if (!endMarker) {
        endMarker = L.marker(e.latlng).addTo(map).bindPopup('Point arrivée').openPopup();
        endCoords = [e.latlng.lat, e.latlng.lng];
    }
});

function getTrajectory() {
    const selectedCity = document.getElementById('city-select').value;
    if (startCoords && endCoords) {
        fetch(`/getTrajectory?start_coords=${startCoords}&end_coords=${endCoords}&city=${selectedCity}`)
            .then(response => response.json())
            .then(data => {
                polylines.forEach(polyline => map.removeLayer(polyline));
                polylines = [];

                data.routes.forEach((route, index) => {
                    const mode = index === 1 ? 'cycling-regular' : 'foot-walking';
                    const style = {
                        color: mode === 'cycling-regular' ? 'green' : 'red',
                        weight: 5,
                        opacity: 0.7
                    };
                    const poly = L.geoJSON(route, { style: style }).addTo(map);
                    polylines.push(poly);
                });

                if (data.start_station_coords && data.start_station_name) {
                    const latlng = [data.start_station_coords.lat, data.start_station_coords.lng];
                    const marker = L.marker(latlng).addTo(map).bindPopup(`Station de départ : ${data.start_station_name}`);
                    marker.openPopup();
                    polylines.push(marker);
                }

                if (data.end_station_coords && data.end_station_name) {
                    const latlng = [data.end_station_coords.lat, data.end_station_coords.lng];
                    const marker = L.marker(latlng).addTo(map).bindPopup(`Station arrivée : ${data.end_station_name}`);
                    polylines.push(marker);
                }

                // Reset des marqueurs de sélection utilisateur
                if (startMarker) {
                    map.removeLayer(startMarker);
                    startMarker = null;
                }
                if (endMarker) {
                    map.removeLayer(endMarker);
                    endMarker = null;
                }

                // Optionnel : centrer la carte sur la trajectoire
                // map.fitBounds(L.featureGroup(polylines).getBounds());
                startCoords = null;
                endCoords = null;
            })
            .catch(err => console.error(err));
    } else {
        alert('Veuillez sélectionner un point de départ et un point d’arrivée.');
    }
}

function reset() {
    if (startMarker) {
        map.removeLayer(startMarker);
        startMarker = null;
    }
    if (endMarker) {
        map.removeLayer(endMarker);
        endMarker = null;
    }

    polylines.forEach(polyline => {
        map.removeLayer(polyline);
    });
    polylines = [];

    startCoords = null;
    endCoords = null;
}
