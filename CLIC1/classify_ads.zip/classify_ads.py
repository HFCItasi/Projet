#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import csv
import re
import sys
from urllib.parse import urlparse
from typing import List, Tuple, Optional, Set

try:
    # Optionnel : si présent, on utilise l'analyseur de listes Adblock “propre”
    from adblockparser import AdblockRules  # type: ignore
    HAS_ADBLOCKPARSER = True
except Exception:
    HAS_ADBLOCKPARSER = False

import pandas as pd

URL_REGEX = re.compile(
    r'(?i)\b((?:https?://|www\.)[^\s<>\]\)"]+|(?:[a-z0-9-]+\.)+[a-z]{2,}/[^\s<>\]\)"]*)'
)

# TLD simple pour filtrer les “faux domaines” dans le fallback
TLD_RE = re.compile(r"\.(com|org|net|io|co|fr|de|es|it|uk|nl|be|ch|ca|us|info|biz|app|site|xyz|online|ai|me|tv|ru|pl|cz|se|no|dk|fi|pt|gr|hu|ro|sk|ie|au|nz)(?:[/:]|$)", re.I)

def extract_urls(text: str) -> List[str]:
    if not isinstance(text, str):
        return []
    urls = URL_REGEX.findall(text)
    # normalise “www.” en http pour parsing homogène
    norm = []
    for u in urls:
        if u.lower().startswith("www."):
            u = "http://" + u
        norm.append(u)
    return norm

def host_from_url(u: str) -> Optional[str]:
    try:
        parsed = urlparse(u if re.match(r'^[a-z]+://', u) else 'http://' + u)
        host = parsed.netloc.lower()
        # retire éventuel port
        host = host.split(':', 1)[0]
        # retire leading “www.”
        if host.startswith("www."):
            host = host[4:]
        return host or None
    except Exception:
        return None

def load_rules_adblock(path: str):
    """Charge les règles via adblockparser si dispo."""
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        raw_rules = [line.strip() for line in f if line.strip()]
    # Filtrage doux: on garde tout, adblockparser gère exceptions/éléments
    rules = AdblockRules(raw_rules)
    return rules

def is_ad_with_adblockparser(rules, url: str) -> Tuple[bool, str]:
    # Le contexte “options” peut influencer (third-party, image, script, etc.).
    # Pour des SMS, on se contente d’un check générique “document”.
    try:
        if rules.should_block(url, {'document': True}):
            return True, "adblockparser:match"
    except Exception:
        pass
    return False, ""

def parse_domains_fallback(path: str) -> Set[str]:
    """
    Fallback simple :
    - ignore commentaires (!) et exceptions (@@)
    - récupère domaines après "||" ou dans des patterns d’URL
    - ignore règles CSS (#@#, ##) et sélecteurs
    """
    domains: Set[str] = set()
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('!') or line.startswith('@@'):
                continue
            if '##' in line or '#@#' in line:
                continue  # element hiding, pas pertinent ici

            # cas 1: ||example.com^
            if line.startswith('||'):
                candidate = line[2:]
                # coupe à l’ancres ^, /, $, |
                candidate = re.split(r'[\^\$\/\|]', candidate, 1)[0]
                if candidate and TLD_RE.search(candidate):
                    domains.add(candidate.lower())

            # cas 2: |http(s)://example.com/...
            elif line.startswith('|http'):
                m = re.match(r'^\|https?:\/\/([^\/\^\$]+)', line, re.I)
                if m:
                    host = m.group(1).lower()
                    host = host.split(':', 1)[0]
                    if host.startswith('www.'):
                        host = host[4:]
                    if TLD_RE.search(host):
                        domains.add(host)

            # cas 3: patterns divers contenant un domaine
            else:
                # on tente d’attraper un nom de domaine plausible
                m = re.search(r'([a-z0-9.-]+\.[a-z]{2,})(?:[\/\^\$\|:]|$)', line, re.I)
                if m:
                    dom = m.group(1).lower()
                    if dom.startswith('www.'):
                        dom = dom[4:]
                    if TLD_RE.search(dom):
                        domains.add(dom)

    return domains

def classify_messages(csv_path: str, adlist_path: str, out_path: str) -> None:
    df = pd.read_csv(csv_path)

    if 'message' not in df.columns:
        raise ValueError("Le CSV doit contenir une colonne 'message'.")

    use_adblock = False
    rules = None
    ad_domains: Set[str] = set()

    if HAS_ADBLOCKPARSER:
        try:
            rules = load_rules_adblock(adlist_path)
            use_adblock = True
        except Exception:
            use_adblock = False

    if not use_adblock:
        ad_domains = parse_domains_fallback(adlist_path)

    is_ads = []
    matched_rules = []
    urls_col = []

    for _, row in df.iterrows():
        text = row.get('message', '')
        urls = extract_urls(text)
        urls_col.append(";".join(urls))

        flagged = False
        reason = ""

        for u in urls:
            if use_adblock and rules is not None:
                ok, why = is_ad_with_adblockparser(rules, u)
                if ok:
                    flagged, reason = True, why
                    break
            else:
                host = host_from_url(u)
                if host:
                    # test du host exact, et des suffixes (ex: a.b.cdn.example.com)
                    parts = host.split('.')
                    for i in range(len(parts) - 1):
                        cand = ".".join(parts[i:])
                        if cand in ad_domains:
                            flagged, reason = True, f"domain:{cand}"
                            break
                    if flagged:
                        break

        is_ads.append(flagged)
        matched_rules.append(reason)

    df_out = df.copy()
    df_out["urls"] = urls_col
    df_out["is_ad"] = is_ads
    df_out["matched_rule"] = matched_rules

    df_out.to_csv(out_path, index=False)
    print(f"Terminé. Fichier écrit : {out_path}")

def main():
    parser = argparse.ArgumentParser(description="Classer les messages en 'ads' ou 'normaux' à partir d'un CSV et d'une liste de pubs.")
    parser.add_argument("--csv", required=True, help="Chemin du CSV (doit contenir une colonne 'message').")
    parser.add_argument("--adlist", required=True, help="Chemin du fichier de règles/URLs (ex: EasyList .txt).")
    parser.add_argument("--out", default="items_with_ads.csv", help="Chemin de sortie du CSV enrichi.")
    args = parser.parse_args()
    classify_messages(args.csv, args.adlist, args.out)

if __name__ == "__main__":
    main()
