===========================================================
        CLASSIFICATION DES MESSAGES PUBLICITAIRES
===========================================================

Ce projet permet de classer automatiquement des messages
(en provenance d’un export de téléphone, par exemple) en deux catégories :
  - Messages publicitaires ("ads")
  - Messages normaux

Le script compare les URLs contenues dans les messages à une
liste de domaines publicitaires issue de filtres Adblock Plus
(par exemple le fichier "[Adblock Plus 2.0].txt").

-----------------------------------------------------------
1. PRÉREQUIS
-----------------------------------------------------------

- Python 3 installé sur votre ordinateur
  (téléchargeable depuis : https://www.python.org/downloads/)
  → Pendant l’installation, cochez l’option :
      "Add Python to PATH"

- Les fichiers suivants doivent être présents dans le même dossier :
    • classify_ads.py
    • _items.csv
    • [Adblock Plus 2.0].txt

Optionnel (pour une détection plus précise) :
  pip install adblockparser

-----------------------------------------------------------
2. CONTENU DES FICHIERS
-----------------------------------------------------------

- _items.csv :
    Fichier contenant les messages à analyser.
    Il doit contenir au minimum une colonne "message"
    (le texte du message).

- [Adblock Plus 2.0].txt :
    Liste de règles de publicité (format EasyList).
    Contient les domaines et filtres utilisés pour détecter les pubs.

- classify_ads.py :
    Script Python qui effectue la classification.

-----------------------------------------------------------
3. UTILISATION (sous PowerShell)
-----------------------------------------------------------

1️⃣  Ouvrez PowerShell dans le dossier contenant les fichiers :
     cd "$env:USERPROFILE\Downloads"

2️⃣  Exécutez la commande suivante :

     python classify_ads.py --csv "_items.csv" --adlist "[Adblock Plus 2.0].txt" --out "items_with_ads.csv"

     (Si la commande 'python' n’est pas reconnue, essayez 'py' à la place)

3️⃣  Le script crée un nouveau fichier :
     items_with_ads.csv

     Ce fichier contient toutes les colonnes d’origine, plus :
       - urls          → URLs trouvées dans le message
       - is_ad         → True / False (pub détectée ou non)
       - matched_rule  → Règle ou domaine correspondant

-----------------------------------------------------------
4. EXEMPLE DE SORTIE
-----------------------------------------------------------

message,urls,is_ad,matched_rule
"Visitez notre site https://ads.google.com","https://ads.google.com",True,"domain:google.com"
"Salut, à ce soir!","",False,""

-----------------------------------------------------------
5. OPTIONS SUPPLÉMENTAIRES
-----------------------------------------------------------

• Spécifier un autre nom de sortie :
    python classify_ads.py --csv "_items.csv" --adlist "[Adblock Plus 2.0].txt" --out "resultats.csv"

• Installer le module optionnel :
    pip install adblockparser

  (Améliore la détection en utilisant les règles complètes Adblock Plus)

-----------------------------------------------------------
6. STRUCTURE DU DOSSIER CONSEILLÉE
-----------------------------------------------------------

/classification_ads/
│
├── classify_ads.py
├── _items.csv
├── [Adblock Plus 2.0].txt
└── README.txt

-----------------------------------------------------------
Auteur : Taha Marif 
Date   : Octobre 2025
===========================================================
