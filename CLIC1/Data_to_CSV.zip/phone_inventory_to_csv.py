import argparse, os, re, csv, io, json, zipfile, mimetypes
from datetime import datetime
from typing import List, Dict, Any

# ---- Helpers ----
def guess_mime(path: str) -> str:
    mime, _ = mimetypes.guess_type(path)
    if mime: return mime
    ext = os.path.splitext(path)[1].lower()
    if ext in [".heic",".heif",".jpg",".jpeg",".png",".gif",".webp"]:
        return "image/*"
    if ext in [".mp4",".mov",".avi",".mkv",".hevc",".3gp"]:
        return "video/*"
    if ext in [".mp3",".wav",".m4a",".aac",".flac",".ogg"]:
        return "audio/*"
    if ext in [".pdf"]:
        return "application/pdf"
    if ext in [".csv",".xml",".json",".txt",".log"]:
        return "text/plain"
    return "application/octet-stream"

def zip_dt(zi):
    return datetime(*zi.date_time)

# ---- Parsers messages ----
def parse_sms_backup_restore_xml(text: str) -> List[Dict[str,Any]]:
    msgs = []
    tag_pat = re.compile(r'<sms\s+[^>]*?>', re.IGNORECASE)
    attrs = re.compile(r'(\w+)="(.*?)"')
    for tag in tag_pat.findall(text):
        d = dict(attrs.findall(tag))
        body = d.get('body','')
        if not body: continue
        try: ts_ms = int(d.get('date','0'))
        except: ts_ms = 0
        ts = datetime.utcfromtimestamp(ts_ms/1000.0).isoformat(' ') if ts_ms else ''
        direction = 'in' if d.get('type') == '1' else ('out' if d.get('type') == '2' else '')
        msgs.append({
            'record_type':'sms','id':'','timestamp':ts,'direction':direction,
            'from': d.get('address','') if direction=='in' else '',
            'to': '' if direction=='in' else d.get('address',''),
            'phone_hash':'','contact_name':d.get('contact_name',''),
            'message':body,'media_filename':'','gps_lat':'','gps_lon':'',
            'app':'sms','app_event':'','device_id':'','imei':'','notes':'source=sms_backup_restore_xml'
        })
    return msgs

def parse_imessage_csv(text: str) -> List[Dict[str,Any]]:
    rows = list(csv.reader(io.StringIO(text)))
    if not rows: return []
    header = [h.strip().lower() for h in rows[0]]
    idx = {k:i for i,k in enumerate(header)}
    msgs=[]
    for r in rows[1:]:
        if not r: continue
        t = r[idx.get('timestamp',-1)] if 'timestamp' in idx else ''
        s = r[idx.get('sender',-1)] if 'sender' in idx else ''
        x = r[idx.get('text',-1)] if 'text' in idx else ''
        if not x: continue
        msgs.append({'record_type':'message','id':'','timestamp':t,'direction':'',
                     'from':s,'to':'','phone_hash':'','contact_name':'','message':x,
                     'media_filename':'','gps_lat':'','gps_lon':'',
                     'app':'imessage','app_event':'','device_id':'','imei':'',
                     'notes':'source=imessage_csv'})
    return msgs

def parse_rcs_json(text: str) -> List[Dict[str,Any]]:
    """
    Robuste: accepte
      - {"messages":[ {...}, ... ]}
      - [ {...}, ... ]
      - {"conversations":[ {"messages":[...]}, ... ] }
    Ignore silencieusement les formats non pertinents.
    """
    try:
        obj = json.loads(text)
    except Exception:
        return []
    msgs = []

    def push(m):
        if not m: return
        ts = m.get('t') or m.get('timestamp') or ''
        frm = m.get('from') or m.get('sender') or ''
        txt = m.get('text') or m.get('body') or ''
        if not txt: return
        msgs.append({
            'record_type':'message','id':'','timestamp':ts,'direction':'',
            'from':frm,'to':'','phone_hash':'','contact_name':'','message':txt,
            'media_filename':'','gps_lat':'','gps_lon':'',
            'app':'rcs','app_event':'','device_id':'','imei':'','notes':'source=rcs_json'
        })

    if isinstance(obj, dict):
        if isinstance(obj.get('messages'), list):
            for m in obj['messages']: 
                if isinstance(m, dict): push(m)
        elif isinstance(obj.get('conversations'), list):
            for conv in obj['conversations']:
                if isinstance(conv, dict) and isinstance(conv.get('messages'), list):
                    for m in conv['messages']:
                        if isinstance(m, dict): push(m)
        # sinon: format inconnu -> ignore
    elif isinstance(obj, list):
        for m in obj:
            if isinstance(m, dict): push(m)

    return msgs

# ---- Export ----
def write_rows(rows, out_csv):
    cols = ['record_type','id','timestamp','direction','from','to','phone_hash',
            'contact_name','message','media_filename','gps_lat','gps_lon',
            'app','app_event','device_id','imei','notes']
    for i,r in enumerate(rows,1):
        r['id']=i
        for c in cols: r.setdefault(c,'')
    with open(out_csv,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols)
        w.writeheader(); w.writerows(rows)

# ---- Inventory ----
def looks_like_messages_json(path_lower: str) -> bool:
    # On ne tente de parser en "messages" que si le chemin l'indique
    hints = ('rcs','message','messages','imessage','whatsapp','telegram','signal')
    return any(h in path_lower for h in hints)

def inventory_zip(zip_path):
    rows=[]
    with zipfile.ZipFile(zip_path,'r') as zf:
        for zi in zf.infolist():
            if zi.is_dir(): continue
            rel=zi.filename; lower=rel.lower()

            # 1) tenter le parsing "messages" seulement si pertinent
            text = ''
            if lower.endswith(('.xml','.csv','.json')):
                try:
                    text = zf.read(zi).decode('utf-8','replace')
                except Exception:
                    text = ''

            if lower.endswith('.xml'):
                rows += parse_sms_backup_restore_xml(text)
            elif lower.endswith('.csv'):
                rows += parse_imessage_csv(text)
            elif lower.endswith('.json') and looks_like_messages_json(lower):
                rows += parse_rcs_json(text)

            # 2) toujours ajouter une ligne "file"
            rows.append({
                'record_type':'file','id':'','timestamp':zip_dt(zi).isoformat(' '),
                'direction':'','from':'','to':'','phone_hash':'','contact_name':'',
                'message':'','media_filename':rel,'gps_lat':'','gps_lon':'',
                'app':'','app_event':'','device_id':'','imei':'',
                'notes':f"mime={guess_mime(rel)}; size={zi.file_size}"
            })
    return rows

def inventory_dir(src_dir):
    rows=[]
    for root,_,files in os.walk(src_dir):
        for fn in files:
            full=os.path.join(root,fn)
            rel=os.path.relpath(full,src_dir)
            lower=rel.lower()

            # 1) tenter le parsing "messages" seulement si pertinent
            if lower.endswith(('.xml','.csv','.json')):
                try:
                    text = open(full,'r',encoding='utf-8',errors='replace').read()
                except Exception:
                    text = ''
                if lower.endswith('.xml'):
                    rows += parse_sms_backup_restore_xml(text)
                elif lower.endswith('.csv'):
                    rows += parse_imessage_csv(text)
                elif lower.endswith('.json') and looks_like_messages_json(lower):
                    rows += parse_rcs_json(text)

            # 2) toujours ajouter une ligne "file"
            st=os.stat(full)
            rows.append({
                'record_type':'file','id':'','timestamp':datetime.fromtimestamp(st.st_mtime).isoformat(' '),
                'direction':'','from':'','to':'','phone_hash':'','contact_name':'',
                'message':'','media_filename':rel,'gps_lat':'','gps_lon':'',
                'app':'','app_event':'','device_id':'','imei':'',
                'notes':f"mime={guess_mime(full)}; size={st.st_size}"
            })
    return rows

def main():
    ap=argparse.ArgumentParser(description="Inventorier un dump téléphone et produire un CSV")
    src=ap.add_mutually_exclusive_group(required=True)
    src.add_argument('--zip'); src.add_argument('--src')
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    rows = inventory_zip(args.zip) if args.zip else inventory_dir(args.src)
    write_rows(rows,args.out)
    print(f"Écrit: {args.out} ({len(rows)} lignes)")

if __name__=="__main__":
    main()
