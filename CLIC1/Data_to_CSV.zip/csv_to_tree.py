#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os
import re
import csv
import zipfile
import shutil
from datetime import datetime
import pandas as pd

# =========================
#        DSL RÈGLES
# =========================
# IMPORTANT: EXTIN doit être AVANT IN pour que "ext=in(...)" ne soit pas capturé par IN.
TOKENS = [
    (r'\s+', None),
    (r'\(', 'LPAREN'),
    (r'\)', 'RPAREN'),
    (r'and\b', 'AND'),
    (r'or\b', 'OR'),
    (r'not\b', 'NOT'),
    (r'([A-Za-z_][A-Za-z0-9_]*)~"([^"]+)"', 'LIKE'),        # col~"regex|alt"
    (r'ext=in\(([^)]+)\)', 'EXTIN'),                        # ext=in(jpg,png,...)
    (r'([A-Za-z_][A-Za-z0-9_]*)=in\(([^)]+)\)', 'IN'),      # col=in(v1,v2)
    (r'([A-Za-z_][A-Za-z0-9_]*)="([^"]+)"', 'EQ'),          # col="val"
    (r'year=(\d{4})', 'YEAR'),                              # year=2025
]

PRECEDENCE = {'NOT': 3, 'AND': 2, 'OR': 1}

def tokenize(s: str):
    pos = 0
    out = []
    while pos < len(s):
        for pat, typ in TOKENS:
            m = re.match(pat, s[pos:], flags=re.IGNORECASE)
            if m:
                if typ:
                    out.append((typ, m.groups()))
                pos += len(m.group(0))
                break
        else:
            raise ValueError("Jeton inconnu près de: " + s[pos:pos+40])
    return out

def to_rpn(tokens):
    out, st = [], []
    for t, v in tokens:
        if t in ('LIKE', 'IN', 'EQ', 'EXTIN', 'YEAR'):
            out.append((t, v))
        elif t in ('AND', 'OR', 'NOT'):
            while st and st[-1] != 'LPAREN' and PRECEDENCE.get(st[-1], 0) >= PRECEDENCE[t]:
                out.append((st.pop(), None))
            st.append(t)
        elif t == 'LPAREN':
            st.append(t)
        elif t == 'RPAREN':
            while st and st[-1] != 'LPAREN':
                out.append((st.pop(), None))
            if not st:
                raise ValueError("Parenthèses non appariées")
            st.pop()
    while st:
        top = st.pop()
        if top in ('LPAREN', 'RPAREN'):
            raise ValueError("Parenthèses non appariées (fin)")
        out.append((top, None))
    return out

def compile_rule(s: str):
    return to_rpn(tokenize(s))

def eval_rule(rpn, ctx: dict) -> bool:
    st = []
    for t, v in rpn:
        if t == 'LIKE':
            col, pattern = v
            text = str(ctx.get(col.lower(), '') or '')
            st.append(re.search(pattern, text, flags=re.IGNORECASE) is not None)

        elif t == 'EXTIN':
            (values,) = v
            exts_rule = [("." + x.strip().lstrip('.').lower()) for x in values.split(',')]
            ext_ctx = (ctx.get('ext', '') or '').lower()
            st.append(ext_ctx in exts_rule)

        elif t == 'IN':
            col, values = v
            vals = [x.strip().strip('"').strip("'") for x in values.split(',')]
            col_l = col.lower()
            val_ctx = str(ctx.get(col_l, '') or '')
            if col_l == 'ext':
                # tolère avec/sans point pour les extensions
                val_ctx_norm = val_ctx.lower().lstrip('.')
                vals_norm = [vv.lower().lstrip('.') for vv in vals]
                st.append(val_ctx_norm in vals_norm)
            else:
                st.append(val_ctx.lower() in [vv.lower() for vv in vals])

        elif t == 'EQ':
            col, val = v
            st.append((str(ctx.get(col.lower(), '') or '')).lower() == val.lower())

        elif t == 'YEAR':
            (y,) = v
            st.append(str(ctx.get('year', '')) == y)

        elif t == 'NOT':
            a = st.pop() if st else False
            st.append(not a)

        elif t in ('AND', 'OR'):
            b = st.pop() if st else False
            a = st.pop() if st else False
            st.append(a and b if t == 'AND' else a or b)

    return bool(st.pop() if st else False)

# =========================
#         LAYOUT
# =========================
class Node:
    def __init__(self, name, rule_text=None):
        self.name = name
        self.rule = compile_rule(rule_text) if rule_text else None
        self.children = []

def parse_layout(path: str) -> "Node":
    with open(path, 'r', encoding='utf-8') as f:
        lines = [ln.rstrip('\n') for ln in f if ln.strip()]
    root = Node('__ROOT__')
    stack = [(-1, root)]  # (depth, node)
    for raw in lines:
        m = re.match(r'^( *)(.+?)\s*(?:=>\s*(.+))?$', raw)
        if not m:
            raise ValueError("Ligne layout invalide: " + raw)
        spaces, name, rule_text = m.groups()
        if len(spaces) % 2 != 0:
            raise ValueError("Indentation (2 espaces) requise: " + raw)
        depth = len(spaces) // 2
        while stack and stack[-1][0] >= depth:
            stack.pop()
        parent = stack[-1][1]
        node = Node(name.strip(), rule_text.strip() if rule_text else None)
        parent.children.append(node)
        stack.append((depth, node))
    return root

def iter_leaves(node: "Node", prefix=()):
    cur = prefix + (node.name,) if node.name != '__ROOT__' else prefix
    if node.name != '__ROOT__' and not node.children:
        yield (node, cur)
    for ch in node.children:
        yield from iter_leaves(ch, cur)

# =========================
#     UTIL & I/O FICHIERS
# =========================
def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def unique_target(dst_dir: str, filename: str) -> str:
    base, ext = os.path.splitext(filename)
    candidate = os.path.join(dst_dir, filename)
    i = 1
    while os.path.exists(candidate):
        candidate = os.path.join(dst_dir, f"{base} ({i}){ext}")
        i += 1
    return candidate

YEAR_MIN, YEAR_MAX = 1995, 2035

def _year_from_text(s: str) -> str:
    s = str(s or "")
    # capture YYYY isolé, sinon fallback sur la première séquence YYYY
    for m in re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', s):
        y = int(m)
        if YEAR_MIN <= y <= YEAR_MAX:
            return str(y)
    m = re.search(r'(?:19|20)\d{2}', s)
    if m:
        y = int(m.group(0))
        if YEAR_MIN <= y <= YEAR_MAX:
            return str(y)
    return ""

def robust_year(media_filename, ts) -> str:
    """
    1) cherche l'année dans le nom de fichier (priorité)
    2) sinon dans le chemin complet
    3) sinon timestamp ISO, puis regex
    """
    base = os.path.basename(str(media_filename or ""))
    y = _year_from_text(base)
    if y: return y
    y = _year_from_text(media_filename)
    if y: return y
    s = str(ts or "").replace("Z", "")
    try:
        return str(datetime.fromisoformat(s).year)
    except Exception:
        pass
    return _year_from_text(s)

# URL detection (pour bucket _URLs)
URL_RE = re.compile(r'(https?://\S+|www\.\S+)', re.IGNORECASE)

def has_url(text: str) -> bool:
    return isinstance(text, str) and URL_RE.search(text) is not None

def write_append_csv(path, fieldnames, row_dict):
    ensure_dir(os.path.dirname(path))
    new_file = not os.path.exists(path)
    with open(path, 'a', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new_file:
            w.writeheader()
        w.writerow(row_dict)

# =========================
#           MAIN
# =========================
def main():
    ap = argparse.ArgumentParser(description="Créer une arborescence à partir d'un CSV (format téléphone) + layout DSL. Bucket auto pour messages avec URL.")
    ap.add_argument('--csv', required=True, help='CSV au format unifié (record_type, timestamp, media_filename, ...)')
    src = ap.add_mutually_exclusive_group(required=False)
    src.add_argument('--zip', help='Archive ZIP d’où copier les fichiers (si media_filename est présent)')
    src.add_argument('--src', help='Dossier source d’où copier/déplacer les fichiers')
    ap.add_argument('--layout', required=True, help='Fichier layout (règles) avec indentation 2 espaces')
    ap.add_argument('--dest', required=True, help='Dossier de destination de l’arbo')
    ap.add_argument('--dry-run', action='store_true', help='Simulation: ne copie rien, affiche le plan')
    ap.add_argument('--move', action='store_true', help='Déplacer depuis --src au lieu de copier')
    ap.add_argument('--urls-bucket-name', default='Messages/_URLs', help='Sous-dossier où dupliquer les messages contenant une URL')
    args = ap.parse_args()

    # Charger CSV
    df = pd.read_csv(args.csv, encoding='utf-8')

    # Champs dérivés
    df['ext']  = df.get('media_filename', '').apply(lambda x: os.path.splitext(str(x))[1].lower() if isinstance(x, str) else '')
    # year priorise le nom de fichier
    df['year'] = [robust_year(row.get('media_filename',''), row.get('timestamp','')) for _, row in df.iterrows()]

    # Parser layout
    root = parse_layout(args.layout)
    leaves = list(iter_leaves(root))  # ordre = priorité (première règle qui matche)

    # Plan d’affectation
    plan = []  # (row, path_tuple)
    for _, row in df.iterrows():
        ctx = {c.lower(): (row[c] if c in row else '') for c in df.columns}
        ctx['ext']  = ctx.get('ext', '') or ''
        ctx['year'] = ctx.get('year', '') or ''
        matched_path = None
        for leaf, path_tuple in leaves:
            if leaf.rule and eval_rule(leaf.rule, ctx):
                matched_path = path_tuple
                break
        if not matched_path:
            matched_path = ('Unsorted',)
        plan.append((row, matched_path))

    # Simulation ?
    if args.dry_run:
        for r, path in plan:
            print(f"{r.get('media_filename','')} -> " + os.path.join(*path))
        return

    # Exécution
    ensure_dir(args.dest)
    zf = None
    members = set()
    if args.zip:
        zf = zipfile.ZipFile(args.zip, 'r')
        members = {zi.filename for zi in zf.infolist() if not zi.is_dir()}

    csv_cols = list(df.columns)

    # Prépare le bucket URL (CSV parallèle)
    urls_bucket_csv = os.path.join(args.dest, *args.urls_bucket_name.split('/'), "_items.csv")

    for r, path_tuple in plan:
        out_dir = os.path.join(args.dest, *path_tuple)
        ensure_dir(out_dir)

        # 1) journaliser chaque ligne dans le dossier cible
        folder_csv = os.path.join(out_dir, "_items.csv")
        write_append_csv(folder_csv, csv_cols, {c: ("" if pd.isna(r.get(c, "")) else r.get(c, "")) for c in csv_cols})

        # 1.b) si c'est un message ET qu'il contient une URL -> dupliquer dans le bucket URLs
        rec_type = str(r.get('record_type', '')).lower()
        msg_text = r.get('message', '')
        if rec_type in ('sms', 'message') and has_url(msg_text):
            write_append_csv(urls_bucket_csv, csv_cols, {c: ("" if pd.isna(r.get(c, "")) else r.get(c, "")) for c in csv_cols})

        # 2) copie/déplacement du fichier associé si dispo
        rel = r.get('media_filename', '')
        if isinstance(rel, str) and rel:
            filename = os.path.basename(rel)
            dst_path = unique_target(out_dir, filename)
            if args.zip and rel in members:
                with zf.open(rel) as src, open(dst_path, 'wb') as out:
                    shutil.copyfileobj(src, out)
            elif args.src:
                src_full = os.path.join(args.src, rel)
                if os.path.exists(src_full):
                    if args.move:
                        shutil.move(src_full, dst_path)
                    else:
                        ensure_dir(os.path.dirname(dst_path))
                        shutil.copy2(src_full, dst_path)

    if zf:
        zf.close()

    print(f"Terminé. Arbo créée dans: {args.dest}")
    print(f"Messages avec URL dupliqués dans: {args.urls_bucket_name}/_items.csv")

if __name__ == '__main__':
    main()
