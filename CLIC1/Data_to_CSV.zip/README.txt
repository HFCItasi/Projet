===========================================================
        PROJET : CLASSIFICATION AUTOMATIQUE DE DONNÉES TÉLÉPHONIQUES
===========================================================

OBJECTIF
-----------------------------------------------------------
Ce projet permet d’extraire et de classer automatiquement les données d’un téléphone
(SMS, iMessage, RCS, photos, vidéos, documents, etc.) à partir d’une archive .zip complète.

Deux scripts assurent le traitement :

1. phone_inventory_to_csv.py  →  extrait les métadonnées du dump ZIP et produit un fichier CSV unifié.
2. csv_to_tree.py              →  lit ce CSV et crée une arborescence de dossiers selon des règles de classification.


CONTENU PRINCIPAL
-----------------------------------------------------------
- phone_dump_big_urls.zip : archive de démonstration simulant un téléphone réel.
  Contient :
    * SMS, iMessage et RCS (avec et sans liens web)
    * Photos, vidéos, captures d’écran (2024–2025)
    * Documents (.pdf, .txt, .json)
    * Journaux d’appels, contacts, données de localisation, médias WhatsApp/Telegram

- phone_inventory_to_csv.py :
    Analyse le ZIP et génère phone_dump.csv (table unifiée de toutes les données).

- csv_to_tree.py :
    Lit le CSV et crée des sous-dossiers selon un layout (topics, années, extensions…).

- layout_urls_by_topic.txt :
    Définit les règles de tri des messages par thème (sport, sortie, réunion, etc.)
    et isole ceux contenant un lien dans un dossier Messages/_URLs.


INSTALLATION
-----------------------------------------------------------
1. Installer Python 3.9 ou supérieur
2. Placer tous les fichiers dans un même dossier :
       phone_inventory_to_csv.py
       csv_to_tree.py
       layout_urls_by_topic.txt
       phone_dump_big_urls.zip
3. Ouvrir un terminal (ou PowerShell) dans ce dossier.


UTILISATION
-----------------------------------------------------------

ÉTAPE 1 : EXTRAIRE LES MÉTADONNÉES DU TÉLÉPHONE
-----------------------------------------------------------
Commande :
    python phone_inventory_to_csv.py --zip phone_dump_big_urls.zip --out phone_dump.csv

Résultat :
    -> Crée un fichier phone_dump.csv contenant toutes les métadonnées :
       SMS, iMessage, RCS, fichiers médias, applications, etc.


ÉTAPE 2 : CRÉER L’ARBORESCENCE CLASSÉE
-----------------------------------------------------------
Commande :
    python csv_to_tree.py --csv phone_dump.csv --zip phone_dump_big_urls.zip --layout layout_urls_by_topic.txt --dest tri_urls_topics

Résultat :
    -> Crée un dossier tri_urls_topics/ contenant :

       tri_urls_topics/
       ├─ Messages/
       │  ├─ Sport/
       │  ├─ Sortie/
       │  ├─ Réunion/
       │  ├─ ...
       │  └─ _URLs/          (tous les messages contenant un lien)
       ├─ Images/
       │  ├─ 2024/
       │  └─ 2025/
       ├─ Vidéos/
       ├─ Audio/
       ├─ Documents/
       └─ Divers/

    Chaque dossier contient un fichier _items.csv listant les fichiers ou messages correspondants.


FONCTIONNALITÉS PRINCIPALES
-----------------------------------------------------------
- Analyse complète d’un dump téléphonique (SMS, iMessage, RCS, médias, fichiers, logs, apps)
- Classification automatique par topic, année, type de fichier, etc.
- Détection automatique des messages contenant des URLs (http, https, www)
- Layout personnalisable (via layout_urls_by_topic.txt)
- Chaque dossier contient un fichier _items.csv avec la liste des éléments triés


EXEMPLES D’ANALYSE
-----------------------------------------------------------
• SMS : "Réunion projet demain. Lien: https://meet.example.com"
    → classé dans : Messages/Réunion/_items.csv
    → dupliqué dans : Messages/_URLs/_items.csv

• Photo : "IMG_20250101.jpg"
    → classée dans : Images/2025/

• Document : "report_2025.json"
    → classé dans : Documents/Données/


CONSEILS
-----------------------------------------------------------
- Simulation sans copie réelle :
    python csv_to_tree.py --csv phone_dump.csv --zip phone_dump_big_urls.zip --layout layout_urls_by_topic.txt --dest tri_urls_topics --dry-run

- Pour un autre téléphone, remplacer simplement l’archive ZIP :
    python phone_inventory_to_csv.py --zip mon_telephone.zip --out mon_telephone.csv


RÉSUMÉ DU PIPELINE
-----------------------------------------------------------
ÉTAPE 1 - Extraction :
    Script : phone_inventory_to_csv.py
    Entrée : phone_dump_big_urls.zip
    Sortie : phone_dump.csv

ÉTAPE 2 - Classification :
    Script : csv_to_tree.py
    Entrées : phone_dump.csv, layout_urls_by_topic.txt
    Sortie : tri_urls_topics/ (arborescence complète)

AUTEUR 
-----------------------------------------------------------

Marif Taha 
Octobre 2025
===========================================================
           FIN DU README - Projet Classification Téléphonique
===========================================================
